<div align="center">
  <h1>
    Brand Icons
  </h1>
  <p>
    Collection of Iranian brand icons with additional awesome <a href="https://github.com/simple-icons/simple-icons">Simple Icons</a>
  </p>
  <p>
    <a href="https://github.com/aasaam/brand-icons/actions/workflows/test.yml">
      <img alt="test" src="https://github.com/aasaam/brand-icons/actions/workflows/test.yml/badge.svg">
    </a>
    <a href="https://github.com/aasaam/brand-icons">
      <img alt="GitHub repo size" src="https://img.shields.io/github/repo-size/aasaam/brand-icons">
    </a>
    <a href="https://www.npmjs.com/package/@aasaam/brand-icons">
      <img alt="npm" src="https://img.shields.io/npm/v/@aasaam/brand-icons">
    </a>
    <a href="https://github.com/aasaam/brand-icons/blob/master/LICENSE.md">
      <img alt="License" src="https://img.shields.io/github/license/aasaam/brand-icons">
    </a>
  </p>
</div>

<div>
  <p align="center">
    <img alt="aasaam software development group" width="64" src="https://raw.githubusercontent.com/aasaam/information/master/logo/aasaam.svg">
    <br />
    aasaam software development group
  </p>
</div>
